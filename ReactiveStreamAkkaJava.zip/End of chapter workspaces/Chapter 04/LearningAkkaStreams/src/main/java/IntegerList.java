import java.util.List;

public class IntegerList {
    public List<Integer> integerList;
}
