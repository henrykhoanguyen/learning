package blockchain;

public class Main {
		
	public static void main(String[] args) {
			
		BlockChainMiner miner = new BlockChainMiner();
		miner.mineBlocks();
		
	}
	
}
