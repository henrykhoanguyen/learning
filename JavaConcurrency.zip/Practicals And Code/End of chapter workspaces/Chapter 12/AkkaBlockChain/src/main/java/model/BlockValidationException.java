package model;

public class BlockValidationException extends Exception {

}
